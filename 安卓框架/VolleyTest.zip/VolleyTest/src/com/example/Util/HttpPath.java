package com.example.Util;

public class HttpPath {
   
	
	//��ַ
	private static final String IP="192.168.0.103:8081";
	
	//get�ύ��װ ����
	public static String getSharedIfo(int id){
		return "http://"+IP+"/GoodsServers/app/getSharedIfo.php?id"+id;
	}
	//post�ύֻ��װ ��ַ url
	public static String getSharedIfo_post(){
		return "http://"+IP+"/GoodsServers/app/getSharedIfo.php";
	}
	//һ��ͼƬ�ĵ�ַ
	public static String getPic(){
		return "http://"+IP+"/GoodsServers/image/201508171125128512.jpg";
	}
	
	//������ַ
	public static String getBasicPath(){
		return "http://"+IP+"/GoodsServers";
	}
	
}
