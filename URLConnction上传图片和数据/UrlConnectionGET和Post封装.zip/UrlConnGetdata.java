package com.example.Http;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.DataInput;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

public class UrlConnGetdata {

	/**
	 * ��������
	 * @param urlpath
	 * @return
	 */
	public static String getData(String urlpath) {

		String result = "getData() ������";

		try {
			URL url = new URL(urlpath);
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();

			conn.setConnectTimeout(5000);
			conn.setRequestMethod("GET");
			conn.setUseCaches(false);

			InputStreamReader isr = new InputStreamReader(conn.getInputStream());

			BufferedReader br = new BufferedReader(isr);
			StringBuffer buffer = new StringBuffer();
			String line = "";
			while ((line = br.readLine()) != null) {
				buffer.append(line);
			}
			br.close();
			isr.close();
			result = buffer.toString();

		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			result += e.getMessage();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			result += e.getMessage();
		}

		return result;

	}
	
	/**
	 * ���ص���ͼƬ
	 * @return
	 */
	public static Bitmap getBitmap(String imgPath){
		
		try {
			URL url=new URL(imgPath);
			HttpURLConnection conn=(HttpURLConnection) url.openConnection();
			
		   conn.setRequestMethod("GET");
		   conn.setConnectTimeout(5000);
		   conn.setUseCaches(false);
		   
		   InputStream is=conn.getInputStream();
		   
		   Bitmap bitmap=BitmapFactory.decodeStream(is);
		   
		   //����ѹ��
		   //bitmap=PictureUtil.compressImage(bitmap);
		   
		   return bitmap;
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	
		return null;
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	

}
