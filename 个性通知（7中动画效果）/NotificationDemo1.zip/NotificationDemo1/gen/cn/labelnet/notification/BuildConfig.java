/** Automatically generated file. DO NOT MODIFY */
package cn.labelnet.notification;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}