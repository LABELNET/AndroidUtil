package cn.labelnet.Animation;

public interface MoveAnimationListener {

	public void onMove(float x, float y);
	
}
