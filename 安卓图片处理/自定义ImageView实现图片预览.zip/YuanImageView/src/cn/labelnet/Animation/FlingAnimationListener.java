package cn.labelnet.Animation;

public interface FlingAnimationListener {

	public void onMove(float x, float y);
	
	public void onComplete();
	
}