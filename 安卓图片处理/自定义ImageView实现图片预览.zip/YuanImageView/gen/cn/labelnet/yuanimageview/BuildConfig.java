/** Automatically generated file. DO NOT MODIFY */
package cn.labelnet.yuanimageview;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}